import platformfactory
from platformfactory import *
import level
from level import *
import lantern
from lantern import *
import exitblock
from exitblock import *

class LevelFactory(object):

	def newLevel(self, level_map, global_coords,dungeon):
			
			tiles = []
			platforms = []
			lanterns = []

			entities = pygame.sprite.Group()

			start_coords = (0,0)
			linked_levels = []

			x = y = 0
			rowindex = 0

			for row in level_map:
				tiles.append([])
				for col in row:
					t = Tile(x,y) #should sort these in order of frequency (most-least)
					if col == "P":
						p = Platform(x, y)
						platforms.append(p)
						entities.add(p)
						t.block = p
					if col == "L":
						l = Lantern(x, y, 2)
						platforms.append(l)
						lanterns.append(l)
						entities.add(l)
						t.block = l
					if col == "N": #N for "next"
						e = ExitBlock(x, y)
						platforms.append(e)
						entities.add(e)
						t.block = e
						#self.linkLevel(linked_levels,global_coords,(x,y), other_levels)
					if col == "S":
						start_coords = (x,y)
					tiles[y/32].append(t)
					x += 32 
				y += 32
				x = 0

			return Level(tiles,entities,platforms,lanterns,dungeon,global_coords,start_coords) 

	def linkLevel(self,linked_levels,global_coords,local_coords, other_levels):
		#TODO
		#linked_levels.append(next_level)
		pass #TODO