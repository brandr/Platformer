import entity
from entity import *

class Lantern(Entity):	#lantern which can help the player see
    def __init__(self, x, y, lightvalue):
        Entity.__init__(self)
        self.color = Color("#FFFF00")
        self.image = Surface((32, 32))
        self.image.convert()
        self.image.fill(BACKGROUND_COLOR)
        self.rect = Rect(x, y, 32, 32)
        self.lightvalue = lightvalue
    def update(self, player): 
        pass
    def update_light(self,tiles):
        self.emit_light(self.lightvalue, tiles)
    def calculate_brightness(self,coords,tiles):
    	other = Tile.tileat(coords,tiles)
    	temp_dist = max(1,self.dist_from(other))
    	temp_dist = max(0,self.lightvalue-temp_dist+1)
    	temp_brightness = ((0.9*temp_dist)/(self.lightvalue))*256
        return min(temp_brightness,255)
    def light_distance(self):
    	return self.lightvalue