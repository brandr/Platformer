import entity
from entity import *

class Platform(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        #self.color = Color("#DDDDDD")
        self.unseen_color = Color("#FFFFFF") #TODO: need "unseen image" instead
        #self.image = Surface((32, 32))
        self.image, self.rect = self.load_image('testblock1.bmp', -1)
        self.image.convert()
        self.rect = Rect(x, y, 32, 32)

    def update(self, player):	
        pass

    def updateimage(self,lightvalue = 0):#visible arg was removed
    	if(lightvalue != 0): 
            self.image = self.load_image('testblock1.bmp')[0]
            #self.image.fill(self.color)
            self.image.set_alpha(lightvalue)
        else: 
            if(self.mapped):
                self.image.fill(self.unseen_color)
                self.image.set_alpha(16)
                return
            self.image.fill(BACKGROUND_COLOR)

    def darkenTo(self, lightvalue):
        self.image = self.load_image('testblock1.bmp')[0]
        current_lightvalue = self.image.get_alpha()
        self.image.set_alpha(min(current_lightvalue, lightvalue))