import os, pygame
from pygame import *
#TODO: implement specific dimming for "mapped" places
BACKGROUND_COLOR = Color("#000000")

class GameImage(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.color = BACKGROUND_COLOR
        self.unseen_color = Color("#000000")
        self.mapped = False
    def load_image(self, name, colorkey = None):
        fullname = os.path.join('data', name)
        try:
            image = pygame.image.load(fullname)
        except pygame.error, message:
            print 'Cannot load image:', name
            raise SystemExit, message
        image = image.convert()
        if colorkey is not None:
            if colorkey is -1:
                colorkey = image.get_at((0,0))
            image.set_colorkey(colorkey, RLEACCEL)
        return image, image.get_rect()
    def updateimage(self, lightvalue = 0): #TODO: change this so that it works for jpg images that have been loaded in. look for ways to alter pixel by pixel (based on lighting)
        if(lightvalue != 0): 
            self.image.fill(self.color)
            self.image.set_alpha(lightvalue)
        else: 
            if(self.mapped):
                self.fully_darken()
                return
            self.image.fill(BACKGROUND_COLOR)  #TODO: eventually split into cases for "mapped" and "not mapped" (plan ahead)
    def darkenTo(self, lightvalue):
        #self.image.fill(self.color)
        
        current_lightvalue = self.image.get_alpha()
        self.image.set_alpha(min(current_lightvalue, lightvalue))
    def check_brightness(self):
        return self.image.get_alpha()
    def fully_darken(self):
        self.image.fill(self.unseen_color)