import entity
from entity import *

class ExitBlock(Entity): #block which exits the level and takes the player elsewhere
	def __init__(self, x, y):
		Entity.__init__(self)
		self.color = Color("#0000FF")
		self.image = Surface((32, 32))
		self.image.convert()
		self.image.fill(BACKGROUND_COLOR)
		self.rect = Rect(x, y, 32, 32)
	#	self.linked_block = None

	#def linkTo(self,other_block):
	#	self.linked_block = other_block
	#	other_block.linked_block = self

	#def linked_block(self):
	#	return self.linked_block

	def update(self, player): 
		pass