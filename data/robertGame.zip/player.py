import entity
from entity import *
import lantern
from lantern import *
import exitblock
from exitblock import *
import platform
from platform import *

class Player(Entity):
    def __init__(self,start_level):
        Entity.__init__(self)
        self.color = Color("#0000FF")
        self.xvel = 0
        self.yvel = 0
        self.onGround = False
        self.image, self.rect = self.load_image('testsprite.bmp', -1)
        colorkey = self.image.get_at((1,1))
        self.image.set_colorkey(colorkey,pygame.RLEACCEL)   
        self.image.convert()
        self.sightdist = 3
        self.current_level = start_level

    def update(self, up, down, left, right, running):
        level = self.current_level
        tiles = level.getTiles()
        entities = level.getEntities()
        platforms = level.getPlatforms()
        lanterns = level.getLanterns()

        if up:
            # only jump if on the ground
            if self.onGround: self.yvel -= 6
        if down:
            pass
        if running:
            self.xvel = 12
        if left:
            self.xvel = -7
        if right:
            self.xvel = 7
        if not self.onGround:
            # only accelerate with gravity if in the air
            self.yvel += 0.3
            # max falling speed
            if self.yvel > 100: self.yvel = 100
        if not(left or right):
            self.xvel = 0
        # increment in x direction
        self.rect.left += self.xvel
        # do x-axis collisions
        self.collide(self.xvel, 0)
        # increment in y direction
        self.rect.top += self.yvel
        # assuming we're in the air
        self.onGround = False;
        # do y-axis collisions
        self.collide(0, self.yvel)
        #TODO: consider a function to update player's image
        self.updateView()
    def updateView(self): #note: this is only to be used in "cave" settings. for areas that are outdoors, use something else.
        level = self.current_level
        if(level.outdoors): 
        #    self.castShadow() #this doesn't work. 
            return
        tiles = level.getTiles()
        lanterns = level.getLanterns()
        for row in tiles:
            for t in row:
                if t.mapped:
                    t.updateimage(False)
        nearby_light_sources = []
        far_light_sources = []
        for l in lanterns:
            if self.invisionrange(l):
                nearby_light_sources.append(l)
            else:
                far_light_sources.append(l)
        for f in far_light_sources:
        	f.update_light(tiles)
        self.emit_light(self.sightdist,tiles,nearby_light_sources)
    def moveTo(self, coords):
        self.rect.left = coords[0]*32
        self.rect.top = coords[1]*32
    def invisionrange(self, other):	#checks if the player can see a platform
        if(self.withindist(other, self.sightdist+other.light_distance())):
            return True
        else:
            return False 
    def getpoint(self,start,end,slope,x):
        p = start
        if(start[0] > end[0]): 
            p = end
        y = p[1] + slope*(x-p[0])
        return (x, y)
    def insiderect(self,p,c1,c2):
        xrectcheck = p[0] >= c1[0] and p[0] <= c2[0] 
        yrectcheck = p[1] >= c1[1] and p[1] <= c2[1] 
        return xrectcheck and yrectcheck
    def collide(self, xvel, yvel): 
        level = self.current_level
        tiles = level.getTiles()
        entities = level.getEntities()
        platforms = level.getPlatforms()
        lanterns = level.getLanterns()

        for p in platforms:
            if pygame.sprite.collide_rect(self, p):
                if isinstance(p, Lantern): #TODO: break this off into its own method as the program grows
                    p.delete()
                    self.sightdist += p.lightvalue
                if isinstance(p, ExitBlock):
                    self.exitLevel(p)
                    return
                if xvel > 0:
                    self.rect.right = p.rect.left
                if xvel < 0:
                    self.rect.left = p.rect.right
                if yvel > 0:
                    self.rect.bottom = p.rect.top
                    self.onGround = True
                    self.yvel = 0
                if yvel < 0:
                    self.rect.top = p.rect.bottom

    def light_distance(self):
    	return self.sightdist

    def exitLevel(self, exit_block):
        self.current_level.movePlayer(exit_block)