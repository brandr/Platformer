import pygame
from pygame import *
import numpy
from numpy import *
import player
from player import *
import levelgroup
from levelgroup import *

DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
DEPTH = 32
FLAGS = 0

class GameScreen:
    def __init__(self):
        pass

    def runGame(self,screen,levels):

        pygame.display.set_caption("Explore the cave!")
        timer = pygame.time.Clock()

        bg = Surface((32,32))
        bg.convert()
        bg.fill(BACKGROUND_COLOR)

        start_level = levels.start_level()
        player = Player(start_level)
        start_level.addPlayer(player)

        up = down = left = right = running = False
        while 1:
            timer.tick(60)

            for e in pygame.event.get():
                if e.type == QUIT: raise SystemExit, "QUIT"
                if e.type == KEYDOWN and e.key == K_ESCAPE:
                    raise SystemExit, "ESCAPE"
                if e.type == KEYDOWN and e.key == K_UP:
                    up = True
                if e.type == KEYDOWN and e.key == K_DOWN:
                    down = True
                if e.type == KEYDOWN and e.key == K_LEFT:
                    left = True
                if e.type == KEYDOWN and e.key == K_RIGHT:
                    right = True
                if e.type == KEYDOWN and e.key == K_SPACE:
                    running = True

                if e.type == KEYUP and e.key == K_UP:
                    up = False
                if e.type == KEYUP and e.key == K_DOWN:
                    down = False
                if e.type == KEYUP and e.key == K_RIGHT:
                    right = False
                if e.type == KEYUP and e.key == K_LEFT:
                    left = False
                if e.type == KEYUP and e.key == K_RIGHT:
                    right = False

        # draw background
            for y in range(32):
                for x in range(32):
                    screen.blit(bg, (x * 32, y * 32))
            player.current_level.update(screen,up, down, left, right, running)